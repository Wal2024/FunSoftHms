# FunSoftHMS
Ready structure.
